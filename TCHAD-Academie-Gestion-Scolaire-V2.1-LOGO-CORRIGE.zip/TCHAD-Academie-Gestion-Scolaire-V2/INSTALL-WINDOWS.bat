@echo off
cd /d "%~dp0"
echo Installation des dependances...
npm install
echo Lancement...
npm start
pause
