const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

let win;
const dataFile = () => path.join(app.getPath('userData'), 'tchad-academie-data.json');
function readDB(){ try { return JSON.parse(fs.readFileSync(dataFile(),'utf8')); } catch { return {}; } }
function writeDB(db){ fs.mkdirSync(path.dirname(dataFile()), {recursive:true}); fs.writeFileSync(dataFile(), JSON.stringify(db,null,2),'utf8'); }
function createWindow(){
  win = new BrowserWindow({width:1440,height:900,minWidth:1050,minHeight:700,backgroundColor:'#F7F3E8',icon:path.join(__dirname,'assets','icon.png'),webPreferences:{preload:path.join(__dirname,'preload.js'),contextIsolation:true,nodeIntegration:false}});
  win.loadFile(path.join(__dirname,'index.html'));
  win.on('closed',()=>win=null);
}
ipcMain.handle('storage:get',(_,key)=>{const db=readDB(); return db[key]===undefined?null:db[key];});
ipcMain.handle('storage:set',(_,key,value)=>{const db=readDB();db[key]=value;writeDB(db);return true;});
ipcMain.handle('storage:clear',()=>{writeDB({});return true;});
ipcMain.handle('backup:export',async()=>{const r=await dialog.showSaveDialog(win,{title:'Sauvegarder TCHAD ACADÉMIE',defaultPath:'tchad-academie-backup.json',filters:[{name:'Sauvegarde JSON',extensions:['json']}]});if(r.canceled)return false;fs.writeFileSync(r.filePath,JSON.stringify(readDB(),null,2),'utf8');return r.filePath;});
ipcMain.handle('backup:import',async()=>{const r=await dialog.showOpenDialog(win,{title:'Restaurer TCHAD ACADÉMIE',properties:['openFile'],filters:[{name:'Sauvegarde JSON',extensions:['json']}]});if(r.canceled)return false;try{const db=JSON.parse(fs.readFileSync(r.filePaths[0],'utf8'));writeDB(db);return true;}catch(e){dialog.showErrorBox('Erreur','Fichier de sauvegarde invalide.');return false;}});
ipcMain.handle('app:print',async()=>{if(!win)return false;const pdf=await win.webContents.printToPDF({printBackground:true,landscape:false});const r=await dialog.showSaveDialog(win,{title:'Exporter en PDF',defaultPath:'rapport-tchad-academie.pdf',filters:[{name:'PDF',extensions:['pdf']}]});if(r.canceled)return false;fs.writeFileSync(r.filePath,pdf);return r.filePath;});
ipcMain.handle('app:info',()=>({version:app.getVersion(),dataFile:dataFile()}));
app.whenReady().then(()=>{Menu.setApplicationMenu(Menu.buildFromTemplate([{label:'Fichier',submenu:[{label:'Sauvegarder',click:()=>win?.webContents.executeJavaScript('window.app.backupExport()')},{label:'Restaurer',click:()=>win?.webContents.executeJavaScript('window.app.backupImport().then(()=>location.reload())')},{type:'separator'},{role:'quit'}]},{label:'Affichage',submenu:[{role:'reload'},{role:'toggledevtools'},{role:'togglefullscreen'}]},{label:'Aide',submenu:[{label:'À propos',click:()=>dialog.showMessageBox(win,{title:'TCHAD ACADÉMIE',message:'Logiciel de gestion scolaire\nVersion '+app.getVersion()+'\nAGROFOOD BUSINESS AND TECHNOLOGY SERVICES (ABTS)'})}]}]));createWindow();app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createWindow();});});
app.on('window-all-closed',()=>{if(process.platform!=='darwin')app.quit();});
