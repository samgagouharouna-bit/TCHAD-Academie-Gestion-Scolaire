const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('storage', {
  get: async (key) => { const v = await ipcRenderer.invoke('storage:get', key); return v == null ? null : { value: JSON.stringify(v) }; },
  set: async (key, value) => { let v=value; try{v=JSON.parse(value)}catch{} await ipcRenderer.invoke('storage:set', key, v); return true; }
});
contextBridge.exposeInMainWorld('app', {
  backupExport: () => ipcRenderer.invoke('backup:export'),
  backupImport: () => ipcRenderer.invoke('backup:import'),
  printPDF: () => ipcRenderer.invoke('app:print'),
  info: () => ipcRenderer.invoke('app:info')
});
